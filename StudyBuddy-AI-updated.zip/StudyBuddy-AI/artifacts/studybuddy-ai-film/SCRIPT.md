# StudyBuddy AI — Film Script

## Director's treatment

- **Promise:** A question can become a clearer next step, with a friendly assistant beside the learner.
- **Identity:** StudyBuddy's existing forest-ink, pale sage, muted apricot, Fraunces and DM Sans palette. The film deepens it into a midnight-green editorial world; Space Grotesk-style condensed display lettering is used only for oversized action words.
- **Hero:** The StudyBuddy conversation itself: a luminous chat panel that transforms from a single question into a useful explanation, then opens into the existing workspace.
- **Motion:** UI cards travel as physical planes through a virtual camera; prompt glyphs scale into picture windows; hand-drawn sage rules connect real features to their moments.
- **Arc:** A one-second curiosity hook accelerates into a guided answer, widens into the existing chat workspace, then pauses to distinguish planned learning tools from current functionality.
- **Payoff:** Rather than another feature card, the ending compresses the whole workspace into a small paper-like study mark against a clean, warm field; its circular punctuation grows into the opening cursor.
- **Format:** 16:9 landscape, 30 seconds.

## Timeline

| Time | Focus | Motion event | Composition | Handoff |
| --- | --- | --- | --- | --- |
| 00.000–04.565 | One question, visibly alive | Three fast cursor/type beats, then the prompt folds into a chat card | Wide ink field; left editorial type, oversized chat plane on right | Prompt bubble scales through lens into answer paper |
| 04.565–10.434 | Step-by-step explanation | Answer assembles in numbered layers; highlight travels line by line | Macro, warm paper plane nearly filling frame | Highlight stroke becomes waveform |
| 10.434–15.652 | Current voice and photo understanding | Photo tile opens, analysis lines draw; voice waveform pulses once then resolves | Split close-up with picture window and voice signal | Three project tabs fan from the image aperture |
| 15.652–20.217 | Current Projects + Recent chats | Camera pulls back through real workspace panels; one conversation routes into a project | Isometric editorial workspace, layered dark panels | Project label pivots into a pale concept field |
| 20.217–25.435 | Planned learning concepts, clearly labeled | Quiz, Notes, Dashboard appear as three distinct concept artifacts, each stamped PLANNED | Cream stage; vertical trio sweeps into an offset triptych | Three paper planes fold into a single bookmark |
| 25.435–30.000 | Brand resolution | Mark resolves, title locks, concept artifacts become a neat study stack; final punctuation becomes opening cursor | Centered sage-on-ink wordmark with generous negative space | Period enlarges to the prompt cursor, seamless loop |

## Full shot script

### Shot 01 / 00.000–04.565 / 4.565s — “A BETTER QUESTION STARTS HERE.”

**Purpose:** Establish the present-day StudyBuddy product through its actual chat interface, not a generic AI promise.

**Exact content and holds:** `A BETTER` appears with the opening reveal at 00.00; `QUESTION` completes the headline at 00.42; `STARTS HERE.` replaces it at 01.05. Prompt field reads `Can you make this make sense?` from 01.55–04.565. Brand `studybuddy.` is on the interface plane from 00.00. No narration.

**Composition:** Midnight forest ink (#111814), framed wide. Headline owns the left 48%; an actual-feeling, dark chat composer plane occupies the right half, angled 4 degrees in perspective. Pale sage cursor, apricot point light. Safe margin 5%. Opening is immediately active; ending prompt card is large and legible at centre-right.

**Artistic idea:** A cursor blink is the initial signal; each keystroke becomes a typographic thump. The completed prompt is itself the camera aperture: its rounded rectangular plane enlarges until it covers the frame.

**Timed choreography:** 0.00 cursor and hairline are already visible. `A BETTER` is present through the first reveal; 0.42 `QUESTION` completes it with a hard 0.16s scale snap. 1.05 copy shears away and `STARTS HERE.` punches in, with a small 0.12s split echo. 1.55–2.65 prompt appears by mask reveal; the caret blinks on the beat. 2.75–3.60 the prompt card tilts forward while its border draws. 3.60–4.565 camera pushes into the card to 2.7x; a soft diagonal panel slices across as the field changes, keeping the prompt's rounded corner visible into the next shot.

**Transition contract:** Prompt plane grows through the lens as answer paper appears beneath it; same rounded corner and sage highlight travel into Shot 02. Use overlap, perspective and a diagonal color split rather than a lone fade.

**Assets and technique:** CSS/HTML mock UI built from confirmed current app styling and actual copy; animated caret and panel geometry. No external image.

**Sound intent:** Instrumental bed only. Opener's snaps aim for nearby rhythmic accents; verify onsets after generation.

### Shot 02 / 04.565–10.434 / 5.869s — “ONE STEP AT A TIME.”

**Purpose:** Show the current chat response's core learning behavior: explain the reasoning in clear, staged language.

**Exact content and holds:** `ONE STEP AT A TIME.` is visible from 04.565. Answer text: `Fractions are parts of a whole.` at 05.615; `1 / 2 means one of two equal pieces.` at 06.615; `Picture one half of a whole apple.` at 07.715. `CLEAR, NOT RUSHED.` is visible from 04.565. No implication that quiz, notes, or dashboard currently exist.

**Composition:** Warm parchment paper (#E8E4D6) breaks the dark opener. A huge answer-sheet plane lies in foreshortened close-up, occupying 78% of short edge. Headline is upper-left; three answer lines cascade across the right and lower half. Warm light from upper left, precise shadows, ink-green annotations.

**Artistic idea:** Each answer line is a physical ruled layer, unfolding one at a time from the notebook fold; a moving sage highlight follows the explanation and becomes the next shot's audio waveform.

**Timed choreography:** 0.00 rounded bubble corner persists, now as sheet corner, with scale easing 1.5→1.0 and focus blur removed over 0.65s. 0.18 headline holds in a decisive two-line composition. 1.05 first answer rule unrolls from a dot; text appears as one settled phrase. 2.05 second rule follows, accompanied by a simple 1/2 diagram where one of two blocks fills sage. 3.15 third line arrives and a simple whole/half glyph marks the idea. 4.10 the highlight sweeps under the sentence then draws a waveform-like zig into the right edge. 4.65–5.20 paper plane pivots sharply and the waveform expands across the cut.

**Transition contract:** The highlight stroke continues its exact line into a waveform in Shot 03. The light parchment shifts to a split-screen, picture aperture without repeating the paper plane's layout.

**Assets and technique:** HTML text, CSS ruled paper, SVG fraction blocks/line and animated mask. Fraunces editorial headline with DM Sans body; no generated text imagery.

**Sound intent:** Bed continues; aim major paper fold at the nearest measured beat.

### Shot 03 / 10.434–15.652 / 5.218s — “SEE IT. HEAR IT.”

**Purpose:** Demonstrate current photo understanding and voice playback without implying image creation is available.

**Exact content and holds:** `SEE IT.` appears in the opening close-up; `HEAR IT.` replaces it at 12.134. Image prompt shown exactly: `What is happening in this diagram?` from 10.434–13.234. Answer tag `A clear explanation, from your photo.` appears at 10.434. Audio tag `Listen to the answer` appears at 10.434. No image-generation claim, no generated image shown.

**Composition:** Deep evergreen split macro: left 58% is a bright ivory image aperture containing a simple photographed-looking paper diagram built as vector illustration (a solar system with clean hand-drawn orbit lines); right 42% is sculptural waveform and short copy. Dominant view at beginning is the diagram close enough to feel tactile; final view pulls back to show the conversation response and voice mark.

**Artistic idea:** The aperture's circular crop makes the photo a lens; analysis traces its orbit lines and turns one orbit into a voice waveform. One continuous signal links photo understanding to spoken answer.

**Timed choreography:** 0.00 incoming highlight stroke enters as orbit; the left image aperture opens radially with a two-panel split reveal. 0.30 prompt label locates at upper left. 1.05 orbit path draws itself; a dot tracks one orbit. 1.70 right-side answer text resolves by phrases, not typewriter. 2.55 orbit exits the aperture as an animated waveform; first line in waveform breathes, then settles. 3.30 `Listen to the answer` tag prints beside a minimal speaker glyph. 4.15 a single waveform pulse expands then contracts; audio playback is suggested visually only (no extra voice layer). 4.85 camera pulls back and image aperture becomes round panel anchor while three slim workspace cards unfold behind it. 5.218 hard cut on the triad.

**Transition contract:** The orbit/picture aperture remains physically present and becomes the round anchor behind the workspace card array. Combine radial opening, a split pivot, and short camera pull.

**Assets and technique:** Custom SVG diagram, orbit and waveform; CSS interface labels. No external photo and no image generated by the product.

**Sound intent:** Instrumental only. A single soft percussion pulse aligns with waveform expansion; no generated SFX or VO. The 15.652s cut aligns with beat 24.

### Shot 04 / 15.652–20.217 / 4.565s — “KEEP YOUR THREAD.”

**Purpose:** Show the current Projects and Recent chats flow as the place a learner's work gathers.

**Exact content and holds:** Sidebar labels `Projects` and `Recent chats`, project names `Math & numbers` and `Science`, and chat titles `Fractions, made simple` and `Forces and motion` resolve as the workspace panels unfold from 15.652. `Your work, still here.` is visible at the lower edge from the opening frame. These are illustrative UI content, not user data.

**Composition:** A dark orbital workspace, wide 16:9, three levels of floating panel depth. Left project rail at 5% inset; central conversation at 38%; right recents tray at 72%. Thin sage dividers, apricot active marker. Opening crops close on the round aperture from Shot 03; ending is wider, ordered, readable.

**Artistic idea:** The camera flies through a conversation bubble, then pulls back to reveal it belongs to a project; chat cards travel along a precise drawn route into the sidebar rather than just appearing in a grid.

**Timed choreography:** 0.00 round image aperture matches to a project-circle icon; three panels unfold in a quick 3D hinge (0.65s). 0.75 the project rail typography resolves; 1.35 two project names populate sequentially. 2.05 camera pushes to `Fractions, made simple` and a light edge sweep identifies it as a current conversation. 2.70 the card moves along an SVG connector into `Math & numbers` (same ID colour and position continuity). 3.65 pull back to overview, recents tray arrives from depth not edge. 4.20 the lower caption remains legible; 4.565 project header rotates around horizontal axis, revealing the pale planned-concepts stage on its reverse.

**Transition contract:** The active project rail becomes a horizontal rule in the next shot; camera rotates the rule into a cream concept-card baseline. Compound with panel hinge and field color inversion.

**Assets and technique:** Product-interface panels are composed as noninteractive artwork, styled after actual current app dark workspace. Perspective CSS transforms, SVG connector and restrained light sweep.

**Sound intent:** Instrumental. Route completion and field pivot target the measured beat. The 20.217s cut aligns with beat 31.

### Shot 05 / 20.217–25.435 / 5.218s — “NEXT: A DEEPER STUDY SPACE.”

**Purpose:** Introduce only the planned roadmap concepts: quiz, notes, study dashboard. Make planned status unmistakable.

**Exact content and holds:** Top label `PLANNED CONCEPTS · NOT CURRENT FEATURES` from 20.217–25.435. `QUIZ` with `Practice, then understand.` appears from 20.467; badge `PLANNED` visible on its card. `NOTES` with `Summaries + revision prompts.` appears from 21.037; badge `PLANNED` visible on its card. `STUDY DASHBOARD` with `A view of your progress.` appears from 21.667; badge `PLANNED` visible on its card. All content holds into the outgoing fold. No authentication features.

**Composition:** Warm parchment stage, confidently unlike the dark workspace. Three oversized concept artifacts form an offset triptych: quiz sheet left and near camera, notes page centered, dashboard tile right. Each card has a terracotta/sage stamp reading `PLANNED`, not interactive buttons. Large title owns upper left; cards occupy lower two thirds. Final grouping is visually distinct from the logo finish.

**Artistic idea:** The three labels are printed from one traveling press: a numbered quiz mark becomes a ruled notes line; that line traces a progress-chart arc. Shared line shows one roadmap, not three features already implemented.

**Timed choreography:** 0.00 incoming baseline unfurls into a horizontal cream card edge; `PLANNED CONCEPTS` is already visible. 0.20 title punches to 1.0, from 1.5 scale. 0.25 quiz card folds up from the edge; numbered choices settle, with `PLANNED` visible. 0.82 notes artifact turns over like a page; two lines appear and the same stamp. 1.45 right dashboard card grows from the notes underline; small progress bars trace up, `PLANNED` stamp visible. 3.25 camera widens to an offset triptych; trio shifts one measured step in sequence, holding all text readable. 4.15 sheets fold inward, stamps turn into little sage squares. 4.70–5.218 the folded stack becomes a singular bookmark silhouette, sweeping into the dark outro.

**Transition contract:** Three panels fold into one bookmark; its small sage square carries into the finale as the brand mark. Layer a page turn, perspective hinge, and simultaneous color field wipe; no blank field.

**Assets and technique:** All learning-feature UI is conceptual graphic artwork made from HTML/CSS/SVG. Stamped PLANNED labels remain legible in each card. No generated photo.

**Sound intent:** Bed continues. Three distinct muted paper taps may be visualized by the actual percussion hits; do not add SFX. The 25.435s cut aligns with beat 39.

### Shot 06 / 25.435–30.000 / 4.565s — “STUDYBUDDY. HERE FOR THE NEXT STEP.”

**Purpose:** End on a calm, memorable brand resolution; clarify the product as a companion, not a feature checklist.

**Exact content and holds:** `studybuddy.` resolves by 26.35 and stays until 30.00. `Here for the next step.` appears by 26.75 and holds through 29.30. No CTA, no new product claim, no voiceover.

**Composition:** Restrained centered paper-sage signature on a dark, almost black-green field, with subtle warm spotlight, ample negative space. The bookmark from Shot 05 shrinks into the small standalone StudyBuddy document/spark mark, faithful to the existing app's outlined page-and-spark symbol (simple custom SVG). Wordmark in DM Sans bold; the dot is muted apricot. Tagline beneath in Fraunces, smaller and quiet. End lockup central and not like any feature shot.

**Artistic idea:** Three roadmap sheets compress into one durable mark; the punctuation in the wordmark is a physical dot that travels back to become Shot 01's blinking prompt caret.

**Timed choreography:** 0.00 bookmark sweeps through the same centre anchor as prior shot; field shifts ink-dark using a two-panel fold. 0.35 mark rotates from edge-on to face, with crisp silhouette and no clutter. 0.25–0.93 `studybuddy.` resolves as one lockup. 0.82 tagline unrolls beneath. 2.30–3.50 camera eases outward and the mark's inner page-line animates once, then stills. 3.50–4.15 all surrounding geometry recedes; tagline remains fully readable until 29.30. 4.15–4.565 the period lifts and grows into a small sage caret against dark field; match its size/position/color to Shot 01's opening cursor for an uninterrupted loop.

**Transition contract:** Final enlarged dot/caret is precisely Shot 01's initial blinking cursor; the field and safe margins match. No fade to empty.

**Assets and technique:** Custom vector adaptation of provided app's existing document-and-spark glyph; no fabricated logo asset. Fraunces/DM Sans, CSS lighting, layered scale and opacity.

**Sound intent:** Music ends on a resolved but unobtrusive chord; loop handoff follows the visual caret. No VO/SFX.

## Composition and pacing review

All adjacent shots vary in at least two dimensions: opener wide/asymmetric dark UI, explanation close/warm paper, photo/voice split/graphic aperture, projects wide/perspective workspace, planned concepts offset cream triptych, outro centered sparse dark lockup. Transitions carry a tangible element (prompt corner, highlight, orbit, project rail, folded bookmark, dot). Every scene has at least one late action and spends its tail in transition rather than an empty hold. Planned functionality is labeled in every card; current app features shown are chat, stepwise explanation, photo understanding, voice playback, Projects and Recent chats. Authentication is outside scope.

## Audio spec
- Runtime: 30 s (SCENE_DURATIONS total).
- Music: locally synthesized, original lo-fi instrumental bed; 92 BPM, soft percussion pulses, muted chord tones, a sparse bell-like motif and rounded bass. No vocals. The `generateMusic` callback was blocked because its paid-mode switch requires user confirmation unavailable in this run, so local synthesis was used. Scripted cuts at 4.565, 10.434, 15.652, 20.217 and 25.435 seconds align to beats 7, 16, 24, 31 and 39 respectively.
- Playback file: `bg_music.mp3`.
