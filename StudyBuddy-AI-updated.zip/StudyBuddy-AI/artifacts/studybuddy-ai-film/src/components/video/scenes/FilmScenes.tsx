import { useState } from 'react';
import { motion } from 'framer-motion';
import { useSceneTimer } from '@/lib/video';

const ease = [0.22, 1, 0.36, 1] as const;
const sectionMotion = {
  initial: { opacity: 0, scale: 1.035 },
  animate: { opacity: 1, scale: 1 },
  exit: { opacity: 0, scale: 0.965 },
  transition: { duration: 0.42, ease },
};

export function Scene01() {
  const [line, setLine] = useState(0);
  const [prompt, setPrompt] = useState(false);
  const [pushing, setPushing] = useState(false);
  useSceneTimer([
    { time: 420, callback: () => setLine(1) },
    { time: 1050, callback: () => setLine(2) },
    { time: 1550, callback: () => setPrompt(true) },
    { time: 3600, callback: () => setPushing(true) },
  ]);
  return (
    <motion.section className="film film-dark scene-enter shot-one" {...sectionMotion}>
      <div className="shot-one-copy">
        <div className="film-kicker" style={{ color: '#a9c6ad' }}>QUESTIONS, IDEAS, EVERYDAY HELP</div>
        <motion.h1
          className="film-display"
          key={line}
          initial={{ opacity: 0, y: 26, scale: 0.93 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.34, ease }}
        >
          {line === 0 ? <>A BETTER</> : line === 1 ? <>A BETTER<br /><em>QUESTION</em></> : <>STARTS<br /><em>HERE.</em></>}
        </motion.h1>
        <motion.div
          className="shot-one-rule"
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 0.35, duration: 0.52, ease }}
        />
        <div className="film-micro" style={{ marginTop: '2.2vh', color: '#87958a' }}>A QUESTION CAN OPEN A DOOR.</div>
      </div>
      <motion.div
        className="chat-mock film-card"
        initial={{ opacity: 0, x: 50, rotateY: -16, scale: 0.91 }}
        animate={pushing
          ? { opacity: [1, 1, 0], x: [0, 0, 0], rotateY: [-10, 0, 0], scale: [1, 1.12, 2.7] }
          : { opacity: 1, x: 0, rotateY: -10, scale: 1 }}
        transition={pushing ? { duration: 0.9, ease: [0.32, 0, 0.7, 1] } : { delay: 0.18, duration: 0.72, ease }}
        style={{ transformOrigin: 'center center' }}
      >
        <div className="chat-top">
          <div className="chat-brand">studybuddy<span style={{ color: '#dda17f' }}>.</span></div>
          <div className="chat-status"><i /> Ready when you are</div>
        </div>
        {prompt && (
          <motion.div
            className="prompt-bubble"
            initial={{ opacity: 0, clipPath: 'inset(0 100% 0 0 round 1.2vmin)' }}
            animate={{ opacity: 1, clipPath: 'inset(0 0% 0 0 round 1.2vmin)' }}
            transition={{ duration: 0.48, ease }}
          >
            Can you make this make sense?<span className="cursor" />
          </motion.div>
        )}
        {prompt && <div className="chat-hint">Ask anything — big or small.</div>}
        <div className="chat-bottom"><span>Questions, ideas, and the little things too.</span><span className="send-orb">↗</span></div>
      </motion.div>
      <div className="shot-one-index film-mono">01 / 06</div>
      <div aria-hidden="true" style={{ position: 'absolute', width: '42vmin', height: '42vmin', border: '1px solid #2b382e', borderRadius: '50%', left: '-20vmin', bottom: '-23vmin' }} />
      <span className="sr-only">StudyBuddy AI. A better question starts here.</span>
    </motion.section>
  );
}

export function Scene02() {
  const [step, setStep] = useState(-1);
  const [handoff, setHandoff] = useState(false);
  useSceneTimer([
    { time: 1050, callback: () => setStep(1) },
    { time: 2050, callback: () => setStep(2) },
    { time: 3150, callback: () => setStep(3) },
    { time: 4650, callback: () => setHandoff(true) },
  ]);
  const rows = [
    'Fractions are parts of a whole.',
    '1 / 2 means one of two equal pieces.',
    'Picture one half of a whole apple.',
  ];
  return (
    <motion.section className="film film-paper scene-enter shot-two" {...sectionMotion}>
      <motion.div
        className="paper-sheet"
        initial={{ opacity: 0, scale: 1.22, rotate: 4 }}
        animate={handoff
          ? { opacity: [1, 1, 0], scale: [1, 1.15, 2.1], rotate: [-1, 0, 4] }
          : { opacity: 1, scale: 1, rotate: -1 }}
        transition={handoff ? { duration: 0.9, ease: [0.32, 0, 0.7, 1] } : { duration: 0.78, ease }}
      >
        <div className="paper-fold" />
        <div className="film-kicker paper-title">A CLEARER WAY THROUGH</div>
        <h2 className="film-display paper-title" style={{ marginTop: '1.2vh', fontSize: '8.1vmin' }}>ONE STEP<br />AT A TIME.</h2>
        <p className="film-copy paper-subtitle">A good explanation meets you where you are.</p>
        <div className="answer-lines">
          {rows.map((text, index) => (
            <motion.div
              className="answer-row"
              key={text}
              initial={{ opacity: 0, x: 36 }}
              animate={{ opacity: index <= step ? 1 : 0, x: 0 }}
              transition={{ duration: 0.56, delay: index * 0.08, ease }}
            >
              <span className="answer-number">0{index + 1}</span>
              <span>{text}</span>
              {index === 1 && (
                <span className="fraction-graphic" aria-hidden="true"><i /><i /></span>
              )}
            </motion.div>
          ))}
        </div>
        <div className="shot-two-note film-micro">CLEAR, NOT RUSHED.</div>
        <motion.div className="underline-track" animate={handoff ? { scaleX: [0.82, 1, 1.4], opacity: [1, 1, 0] } : { scaleX: [0.82, 0.95, 0.82] }} transition={handoff ? { duration: 0.9, ease } : { duration: 2.2, repeat: Infinity, ease: 'easeInOut' }} />
        <div className="shot-two-corner">02</div>
      </motion.div>
    </motion.section>
  );
}

export function Scene03() {
  const [answer, setAnswer] = useState(false);
  useSceneTimer([{ time: 1700, callback: () => setAnswer(true) }]);
  const bars = [22, 35, 65, 42, 82, 48, 34, 73, 50, 88, 37, 60, 28, 72, 44, 56, 32, 78, 39, 62, 27, 51, 35];
  return (
    <motion.section className="film film-dark scene-enter shot-three" {...sectionMotion}>
      <motion.div
        className="photo-window"
        initial={{ clipPath: 'circle(0% at 48% 48%)', scale: 1.12 }}
        animate={{ clipPath: 'circle(95% at 48% 48%)', scale: 1 }}
        transition={{ duration: 0.82, ease }}
      >
        <div className="photo-label film-kicker">PHOTO UNDERSTANDING</div>
        <div className="diagram-sun" />
        <div className="orbit" />
        <div className="orbit orbit-two" />
        <div className="planet" />
        <div className="planet planet-two" />
        <div className="orbit-caption film-micro">A DIAGRAM, THROUGH YOUR LENS</div>
        <div className="photo-question">What is happening in this diagram?</div>
      </motion.div>
      <div className="voice-column">
        <motion.div
          className="film-kicker"
          initial={{ opacity: 0, x: 18 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3, duration: 0.5, ease }}
          style={{ color: '#a9c6ad', marginBottom: '1.5vh' }}
        >
          CURRENT FEATURES
        </motion.div>
        <motion.h2
          className="film-word"
          key={answer ? 'hear' : 'see'}
          initial={{ opacity: 0, scale: 1.18, filter: 'blur(7px)' }}
          animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
          transition={{ duration: 0.42, ease }}
        >
          {answer ? <>HEAR<br />IT.</> : <>SEE<br />IT.</>}
        </motion.h2>
        <div className="film-copy voice-caption">A clear explanation, from your photo.</div>
        <div className="voice-wave" aria-hidden="true">
          {bars.map((height, index) => (
            <motion.i
              key={`${index}-${height}`}
              style={{ height: `${height}%` }}
              animate={{ scaleY: [0.72, index % 3 === 0 ? 1 : 0.9, 0.72] }}
              transition={{ duration: 0.68 + (index % 4) * 0.08, repeat: Infinity, ease: 'easeInOut', delay: (index % 8) * 0.045 }}
            />
          ))}
        </div>
        <div className="listen-tag"><span className="listen-icon">Ⅱ</span> Listen to the answer</div>
      </div>
    </motion.section>
  );
}

export function Scene04() {
  const [route, setRoute] = useState(false);
  useSceneTimer([{ time: 2650, callback: () => setRoute(true) }]);
  return (
    <motion.section className="film film-dark scene-enter shot-four" {...sectionMotion}>
      <div className="workspace-crumb film-kicker"><span style={{ color: '#a9c6ad' }}>STUDYBUDDY</span><span>/</span><span>YOUR WORKSPACE</span></div>
      <motion.div
        className="workspace-grid"
        initial={{ opacity: 0, scale: 0.79, rotateX: 8 }}
        animate={{ opacity: 1, scale: 1, rotateX: 0 }}
        transition={{ duration: 0.82, ease }}
      >
        <div className="workspace-panel workspace-rail">
          <h3 className="workspace-heading">Projects</h3>
          <div className="project-line active"><i className="project-dot" /> Math &amp; numbers</div>
          <div className="project-line"><i className="project-dot green" /> Science</div>
          <div className="project-line" style={{ color: '#819083' }}>＋ New project</div>
        </div>
        <div className="workspace-panel workspace-chat">
          <div className="film-micro" style={{ color: '#93a297' }}>MATH &amp; NUMBERS</div>
          <div className="workspace-question">Can you explain fractions simply?</div>
          <motion.div
            className="workspace-answer"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.6, ease }}
          >
            <b>Fractions are parts of a whole.</b><br />
            Think of one whole divided into equal pieces. Let’s start with one half.
          </motion.div>
        </div>
        <div className="workspace-panel workspace-recent">
          <h3 className="workspace-heading">Recent chats</h3>
          <div className="recent-row">Fractions, made simple<span>Math &amp; numbers · just now</span></div>
          <div className="recent-row">Forces and motion<span>Science · yesterday</span></div>
        </div>
        <motion.div
          className="workspace-path"
          initial={{ opacity: 0, scaleX: 0, scaleY: 0.2 }}
          animate={{ opacity: route ? 1 : 0.35, scaleX: route ? 1 : 0.42, scaleY: 1 }}
          transition={{ duration: 0.68, ease }}
        />
      </motion.div>
      <div className="workspace-caption film-copy">Your work, still here.</div>
    </motion.section>
  );
}

export function Scene05() {
  const [folding, setFolding] = useState(false);
  useSceneTimer([{ time: 4150, callback: () => setFolding(true) }]);
  return (
    <motion.section className="film film-paper scene-enter shot-five" {...sectionMotion}>
      <div className="concept-kicker film-kicker">PLANNED CONCEPTS · NOT CURRENT FEATURES</div>
      <h2 className="film-display concept-title">NEXT: A DEEPER<br /><em>STUDY SPACE.</em></h2>
      <div className="concept-triptych">
        <motion.article
          className="concept-card"
          initial={{ opacity: 0, y: 70, rotate: -10 }}
          animate={folding ? { opacity: [1, 1, 0], y: [0, 0, 28], rotate: [-4, -1, 8], scale: [1, 1, 0.72] } : { opacity: 1, y: 0, rotate: -4 }}
          transition={folding ? { duration: 0.72, ease } : { delay: 0.25, duration: 0.72, ease }}
        >
          <span className="planned-stamp">PLANNED</span>
          <h3>QUIZ</h3>
          <p>Practice, then understand.</p>
          <div className="quiz-options"><i /><i /><i /></div>
        </motion.article>
        <motion.article
          className="concept-card"
          initial={{ opacity: 0, y: 66, rotate: 8 }}
          animate={folding ? { opacity: [1, 1, 0], y: [0, 0, 28], rotate: [0, 0, -6], scale: [1, 1, 0.72] } : { opacity: 1, y: 0, rotate: 0 }}
          transition={folding ? { duration: 0.72, ease } : { delay: 0.82, duration: 0.74, ease }}
        >
          <span className="planned-stamp">PLANNED</span>
          <h3>NOTES</h3>
          <p>Summaries + revision prompts.</p>
          <div className="notes-rules"><i /><i /><i /></div>
        </motion.article>
        <motion.article
          className="concept-card"
          initial={{ opacity: 0, y: 74, rotate: 12 }}
          animate={folding ? { opacity: [1, 1, 0], y: [0, 0, 28], rotate: [3, 1, -8], scale: [1, 1, 0.72] } : { opacity: 1, y: 0, rotate: 3 }}
          transition={folding ? { duration: 0.72, ease } : { delay: 1.45, duration: 0.74, ease }}
        >
          <span className="planned-stamp">PLANNED</span>
          <h3 style={{ fontSize: '3.1vmin' }}>STUDY<br />DASHBOARD</h3>
          <p>A view of your progress.</p>
          <div className="dashboard-bars" aria-hidden="true"><i /><i /><i /><i /><i /></div>
        </motion.article>
      </div>
      <motion.div className="concept-sweep" initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 1.8, duration: 0.8, ease }} />
    </motion.section>
  );
}

export function Scene06() {
  return (
    <motion.section className="film film-dark scene-enter shot-six" {...sectionMotion}>
      <div className="final-rings" aria-hidden="true" />
      <motion.div
        className="signature"
        initial={{ opacity: 0, scale: 0.84 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.88, ease }}
      >
        <motion.svg
          className="brand-glyph"
          viewBox="0 0 64 64"
          fill="none"
          aria-label="StudyBuddy document and spark symbol"
          initial={{ rotate: -22, scale: 0.64 }}
          animate={{ rotate: 0, scale: 1 }}
          transition={{ duration: 0.72, ease }}
        >
          <path d="M12 20c0-2.2 1.8-4 4-4h31c2.2 0 4 1.8 4 4v26c0 2.2-1.8 4-4 4H16c-2.2 0-4-1.8-4-4V20Z" stroke="currentColor" strokeWidth="2.4" />
          <path d="M21 27h21M21 34h16M21 41h12" stroke="currentColor" strokeWidth="2.3" strokeLinecap="round" />
          <path d="m46 7 2.1 5.7 5.9 2.1-5.9 2.1L46 23l-2.1-6.1-5.9-2.1 5.9-2.1L46 7Z" fill="#dda17f" />
        </motion.svg>
        <motion.h1
          className="brand-lockup"
          initial={{ opacity: 0, letterSpacing: '.08em' }}
          animate={{ opacity: 1, letterSpacing: '-.075em' }}
          transition={{ delay: 0.25, duration: 0.68, ease }}
        >
          studybuddy<span className="period">.</span>
        </motion.h1>
        <motion.p
          className="brand-tagline"
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.82, duration: 0.58, ease }}
        >
          Here for the next step.
        </motion.p>
      </motion.div>
      <motion.div
        className="final-caret"
        aria-hidden="true"
        animate={{ scaleY: [1, 0.75, 1], opacity: [1, 0.85, 1] }}
        transition={{ delay: 2.1, duration: 1.25, repeat: Infinity, ease: 'easeInOut' }}
      />
    </motion.section>
  );
}
