(() => {
  const $ = (selector) => document.querySelector(selector);
  const sidebar = $('.side-panel');
  const newChat = $('#new-chat-button');
  if (!sidebar || !newChat) return;

  const settingsButton = document.createElement('button');
  settingsButton.type = 'button';
  settingsButton.className = 'sidebar-action premium-side-action';
  settingsButton.id = 'settings-button';
  settingsButton.innerHTML = '<span aria-hidden="true">⚙</span> Settings';
  newChat.insertAdjacentElement('afterend', settingsButton);

  const activityButton = document.createElement('button');
  activityButton.type = 'button';
  activityButton.className = 'sidebar-action premium-side-action';
  activityButton.id = 'activity-button';
  activityButton.innerHTML = '<span aria-hidden="true">✦</span> Fun activities';
  settingsButton.insertAdjacentElement('afterend', activityButton);

  const modal = document.createElement('div');
  modal.className = 'premium-modal-backdrop';
  modal.id = 'premium-modal';
  modal.hidden = true;
  modal.innerHTML = `<section class="premium-modal" role="dialog" aria-modal="true" aria-labelledby="premium-modal-title">
    <button class="premium-modal-close" type="button" aria-label="Close">×</button>
    <div class="premium-modal-kicker">STUDYBUDDY / PERSONALIZE</div><h2 id="premium-modal-title">Your workspace</h2>
    <p class="premium-modal-subtitle" id="premium-modal-subtitle">Make your study space feel right for you.</p>
    <div class="settings-options" id="settings-options">
      <label class="settings-row"><span><b>Light appearance</b><small>Switch between dark and light themes</small></span><input id="theme-toggle" type="checkbox"></label>
      <label class="settings-row"><span><b>Compact layout</b><small>Fit more chats and content on screen</small></span><input id="compact-toggle" type="checkbox"></label>
      <label class="settings-row"><span><b>Larger text</b><small>Make the interface easier to read</small></span><input id="text-toggle" type="checkbox"></label>
      <button class="settings-danger" id="clear-history-button" type="button">Clear saved chats and projects</button>
      <p class="settings-note">Your account and sign-in details are not affected.</p>
    </div>
    <div class="activity-content" id="activity-content" hidden><div class="activity-orb">✦</div><div class="activity-chip">QUICK RESET · 2 MIN</div><h3 id="activity-title">Take a tiny brain break</h3><p id="activity-description">Roll your shoulders, look away from the screen, and take five slow breaths.</p><button class="activity-next" id="activity-next" type="button">Another activity ↗</button><button class="activity-try" id="activity-try" type="button">Ask StudyBuddy about this</button></div>
  </section>`;
  document.body.append(modal);

  const themeToggle = $('#theme-toggle');
  const compactToggle = $('#compact-toggle');
  const textToggle = $('#text-toggle');
  const settingsContent = $('#settings-options');
  const activityContent = $('#activity-content');
  const activities = [
    ['Two-minute reset', 'Roll your shoulders, look away from the screen, and take five slow breaths.'],
    ['Memory sprint', 'Pick three things you learned today and explain each one in a single sentence.'],
    ['Desk detective', 'Find one thing on your desk that starts with the first letter of your name.'],
    ['Tiny drawing challenge', 'Draw a tiny rocket, book, or friendly robot on paper in 60 seconds.'],
    ['Word chain', 'Choose a word from your subject, then think of five related words as quickly as you can.'],
    ['Gratitude pause', 'Name one thing that went well today and one thing you want to understand better.'],
    ['Focus quest', 'Choose one small task you can finish in the next ten minutes. Make it your mini mission.']
  ];
  let activityIndex = 0;
  const preferenceKey = 'studybuddy.preferences.v1';
  let prefs = {};
  try { prefs = JSON.parse(localStorage.getItem(preferenceKey) || '{}'); } catch {}
  const applyPrefs = () => {
    document.body.classList.toggle('theme-light', !!prefs.light);
    document.body.classList.toggle('compact-layout', !!prefs.compact);
    document.body.classList.toggle('large-text', !!prefs.largeText);
    themeToggle.checked = !!prefs.light;
    compactToggle.checked = !!prefs.compact;
    textToggle.checked = !!prefs.largeText;
  };
  const savePrefs = () => { try { localStorage.setItem(preferenceKey, JSON.stringify(prefs)); } catch {} applyPrefs(); };
  applyPrefs();

  function openModal(mode) {
    const isActivity = mode === 'activity';
    $('#premium-modal-title').textContent = isActivity ? 'A little fun break' : 'Your workspace';
    $('#premium-modal-subtitle').textContent = isActivity ? 'Reset your brain, then come back refreshed.' : 'Make your study space feel right for you.';
    settingsContent.hidden = isActivity;
    activityContent.hidden = !isActivity;
    modal.hidden = false;
    document.body.classList.add('modal-open');
  }
  function closeModal() { modal.hidden = true; document.body.classList.remove('modal-open'); }
  settingsButton.addEventListener('click', () => openModal('settings'));
  activityButton.addEventListener('click', () => openModal('activity'));
  $('.premium-modal-close').addEventListener('click', closeModal);
  modal.addEventListener('click', (event) => { if (event.target === modal) closeModal(); });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeModal(); });
  themeToggle.addEventListener('change', () => { prefs.light = themeToggle.checked; savePrefs(); });
  compactToggle.addEventListener('change', () => { prefs.compact = compactToggle.checked; savePrefs(); });
  textToggle.addEventListener('change', () => { prefs.largeText = textToggle.checked; savePrefs(); });
  function showActivity() {
    activityIndex = Math.floor(Math.random() * activities.length);
    $('#activity-title').textContent = activities[activityIndex][0];
    $('#activity-description').textContent = activities[activityIndex][1];
  }
  $('#activity-next').addEventListener('click', showActivity);
  $('#activity-try').addEventListener('click', () => {
    const input = $('#message-input');
    if (input) {
      input.value = `Help me try this quick activity: ${activities[activityIndex][0]}. ${activities[activityIndex][1]}`;
      input.focus();
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }
    closeModal();
  });
  $('#clear-history-button').addEventListener('click', () => {
    if (!window.confirm('Delete all saved chats and projects from this browser? This cannot be undone.')) return;
    try { localStorage.removeItem('studybuddy.workspace.v1'); } catch {}
    window.location.reload();
  });
  showActivity();
})();
