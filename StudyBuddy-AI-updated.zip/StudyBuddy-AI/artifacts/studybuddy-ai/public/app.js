(() => {
  const SUPABASE_URL = "https://uyonyantxihlcwmgzihm.supabase.co";
  const SUPABASE_KEY = "sb_publishable_8A7ZPiuKEaeXYG8FVDo8pg_k13jsK2Q";
  const supabaseClient = window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_KEY,
  );
  const authScreen = document.getElementById("auth-screen");
  const appShell = document.querySelector(".app-shell");
  const authForm = document.getElementById("auth-form");
  const authTitle = document.getElementById("auth-title");
  const authToggle = document.getElementById("auth-toggle");
  const authSubmit = document.getElementById("auth-submit");
  const authMessage = document.getElementById("auth-message");

  let isSignup = false;

  function updateAccountMenu(session) {
    const container = document.getElementById("profileMenuContainer");
    const dropdown = document.getElementById("profileDropdown");
    const button = document.getElementById("profileButton");
    const emailNode = document.getElementById("profileAccountEmail");
    const nameNode = document.getElementById("profileAccountName");
    const buttonAvatar = document.getElementById("profileButtonAvatar");
    const buttonFallback = document.getElementById("profileButtonFallback");
    const dropdownAvatar = document.getElementById("profileDropdownAvatar");
    const dropdownFallback = document.getElementById("profileDropdownFallback");
    const user = session?.user || null;
    const guest = !user && localStorage.getItem("studybuddy.guest") === "1";

    if (container) container.hidden = !user && !guest;
    if (!user && !guest) {
      if (dropdown) dropdown.hidden = true;
      if (button) button.setAttribute("aria-expanded", "false");
      return;
    }
    if (guest) {
      if (emailNode) emailNode.textContent = "Anonymous session · Free";
      if (nameNode) nameNode.textContent = "Guest user";
      if (buttonAvatar) buttonAvatar.hidden = true;
      if (dropdownAvatar) dropdownAvatar.hidden = true;
      if (buttonFallback) buttonFallback.hidden = false;
      if (dropdownFallback) dropdownFallback.hidden = false;
      return;
    }

    const email = user.email || "Email not available";
    const metadata = user.user_metadata || {};
    const displayName = metadata.full_name || metadata.name || metadata.display_name || email.split("@")[0] || "StudyBuddy user";
    const avatarUrl = metadata.avatar_url || metadata.picture || metadata.profile_image || "";
    if (emailNode) emailNode.textContent = email;
    if (nameNode) nameNode.textContent = displayName;

    const setAvatar = (img, fallback) => {
      if (!img || !fallback) return;
      img.onerror = () => { img.hidden = true; fallback.hidden = false; };
      if (avatarUrl) {
        img.src = avatarUrl;
        img.hidden = false;
        fallback.hidden = true;
      } else {
        img.removeAttribute("src");
        img.hidden = true;
        fallback.hidden = false;
      }
    };
    setAvatar(buttonAvatar, buttonFallback);
    setAvatar(dropdownAvatar, dropdownFallback);
  }

  function showAuth(session) {
    const loggedIn = Boolean(session?.user) || localStorage.getItem("studybuddy.guest") === "1";
    authScreen.style.display = loggedIn ? "none" : "flex";
    appShell.style.display = loggedIn ? "" : "none";
    updateAccountMenu(session);
  }

  // The logout button uses Supabase's client session directly; no missing server route is required.
  window.studyBuddySignOut = async () => {
    const { error } = await supabaseClient.auth.signOut();
    if (error) throw error;
  };

  document.getElementById("guest-mode-button")?.addEventListener("click", () => {
    localStorage.setItem("studybuddy.guest", "1");
    showAuth(null);
    startGuestFreshChat();
  });
  function startGuestFreshChat() {
    // The main chat initializer is below; a fresh page starts with empty AI context.
    window.location.reload();
  }

  authToggle.addEventListener("click", () => {
    isSignup = !isSignup;
    authTitle.textContent = isSignup ? "Create your account" : "Welcome back";
    authSubmit.textContent = isSignup ? "Sign up" : "Login";
    authToggle.textContent = isSignup ? "Back to Login" : "Create account";
    authMessage.textContent = "";
  });

  authForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const email = document.getElementById("auth-email").value.trim();
    const password = document.getElementById("auth-password").value;

    authSubmit.disabled = true;
    authMessage.textContent = "Please wait...";

    try {
      const result = isSignup
        ? await supabaseClient.auth.signUp({ email, password })
        : await supabaseClient.auth.signInWithPassword({ email, password });

      if (result.error) throw result.error;

      if (isSignup && !result.data.session) {
        authMessage.textContent =
          "Account created! Check your email to confirm, then log in.";
      } else {
        authMessage.textContent = "Success!";
        showAuth(result.data.session);
      }
    } catch (error) {
      authMessage.textContent = error.message || "Something went wrong.";
    } finally {
      authSubmit.disabled = false;
    }
  });

  supabaseClient.auth.onAuthStateChange((_event, session) => {
    showAuth(session);
  });

  supabaseClient.auth.getSession().then(({ data, error }) => {
    if (error) {
      authMessage.textContent = error.message;
      showAuth(null);
      return;
    }

    showAuth(data.session);
  });
  const quotaCount = document.getElementById("quota-count");
  const quotaRemaining = document.getElementById("quota-remaining");
  const quotaReset = document.getElementById("quota-reset");
  const quotaProgress = document.getElementById("quota-progress");
  let quotaState = { used: 0, limit: 25, remaining: 25, resetAt: null };
  let quotaTick = null;
  async function refreshQuota() {
    try {
      const response = await fetch("/api/quota", { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data?.error || "Quota unavailable");
      quotaState = data;
      renderQuota();
    } catch (error) {
      if (quotaCount) quotaCount.textContent = "Unavailable";
      if (quotaRemaining) quotaRemaining.textContent = "Question limit setup needed";
      if (quotaReset) quotaReset.textContent = "";
    }
  }
  function renderQuota() {
    const used = Math.min(25, Number(quotaState.used || 0));
    if (quotaCount) quotaCount.textContent = `${used}/25`;
    if (quotaRemaining) quotaRemaining.textContent = `${Math.max(0, 25-used)} remaining`;
    if (quotaProgress) quotaProgress.style.width = `${used / 25 * 100}%`;
    const locked = used >= 25 && quotaState.resetAt && Date.parse(quotaState.resetAt) > Date.now();
    if (quotaReset) {
      if (locked) {
        const seconds = Math.max(0, Math.floor((Date.parse(quotaState.resetAt)-Date.now())/1000));
        quotaReset.textContent = `Resets in ${Math.floor(seconds/3600)}h ${Math.floor((seconds%3600)/60)}m ${seconds%60}s`;
      } else quotaReset.textContent = quotaState.resetAt ? `Resets ${new Date(quotaState.resetAt).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"})}` : "Rolling 24-hour limit";
    }
    if (input) { input.disabled = Boolean(locked); input.placeholder = locked ? "Daily question limit reached" : "Ask StudyBuddy anything…"; }
    if (sendButton) sendButton.disabled = Boolean(locked) || sending || preparingRequest;
    if (locked && quotaRemaining) quotaRemaining.textContent = "Limit reached — wait for reset";
  }
  refreshQuota();
  quotaTick = window.setInterval(() => {
    if (quotaState.resetAt && Date.parse(quotaState.resetAt) <= Date.now()) refreshQuota();
    else renderQuota();
  }, 1000);

  const form = document.getElementById("chat-form");
  const input = document.getElementById("message-input");
  const sendButton = document.getElementById("send-button");
  const messages = document.getElementById("messages");
  const welcome = document.getElementById("welcome");
  const errorBox = document.getElementById("error-message");
  const stopVoiceButton = document.getElementById("stop-voice-button");
  const topbarRight = document.getElementById("topbar-right");
  const imageInput = document.getElementById("image-input");
  const attachButton = document.getElementById("attach-button");
  const attachmentTray = document.getElementById("attachment-tray");
  const imageStatus = document.getElementById("image-status");
  const projectList = document.getElementById("project-list");
  const recentList = document.getElementById("recent-list");
  const newChatButton = document.getElementById("new-chat-button");
  const newProjectButton = document.getElementById("new-project-button");
  const activeProjectLabel = document.getElementById("active-project-label");
  const sidebar = document.getElementById("sidebar");
  const mobileMenuButton = document.getElementById("mobile-menu-button");

  const history = [];
  const attachments = [];
  const STORAGE_KEY = "studybuddy.workspace.v1";
  const now = () => new Date().toISOString();
  let projects = [];
  let chats = [];
  let activeChatId = null;
  let selectedProjectId = null;
  let explicitlySelectedProject = false;
  let storageWarningShown = false;
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    projects = Array.isArray(saved.projects)
      ? saved.projects.filter((item) => item && item.id && item.name)
      : [];
    chats = Array.isArray(saved.chats)
      ? saved.chats.filter(
          (item) => item && item.id && Array.isArray(item.messages),
        )
      : [];
  } catch {
    projects = [];
    chats = [];
  }

  function persistWorkspace() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ projects, chats }));
      storageWarningShown = false;
      return true;
    } catch {
      if (!storageWarningShown) {
        storageWarningShown = true;
        showError(
          "This conversation is still available here, but browser storage is unavailable. Free up space or enable local storage to keep it after reload.",
        );
      }
      return false;
    }
  }

  function makeId() {
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
  }

  const topicRules = [
    {
      name: "Math & numbers",
      words:
        "math maths algebra fraction fractions geometry calculus equation equations trigonometry गणित hisaab",
    },
    {
      name: "Science",
      words:
        "science physics chemistry biology experiment atom energy force जीवविज्ञान विज्ञान",
    },
    {
      name: "Writing & language",
      words:
        "write writing essay grammar language hindi english translate translation कहानी कविता पत्र",
    },
    {
      name: "Planning & productivity",
      words:
        "plan planning schedule week routine productivity time goal goals organize organize करूँ योजना समय",
    },
    {
      name: "Food & cooking",
      words:
        "food dinner recipe cooking cook meal breakfast lunch खाना रेसिपी भोजन",
    },
    {
      name: "Technology",
      words:
        "technology computer code coding javascript python app website internet phone तकनीक कंप्यूटर",
    },
    {
      name: "History & society",
      words: "history historical society culture देश इतिहास समाज",
    },
    {
      name: "Health & wellbeing",
      words:
        "health sleep stress exercise fitness wellbeing स्वास्थ्य नींद तनाव",
    },
  ];
  const topicStopWords = new Set([
    "the",
    "and",
    "for",
    "with",
    "that",
    "this",
    "what",
    "how",
    "can",
    "could",
    "does",
    "did",
    "will",
    "would",
    "should",
    "please",
    "explain",
    "help",
    "make",
    "tell",
    "about",
    "from",
    "have",
    "you",
    "your",
    "best",
    "way",
    "simple",
    "easy",
    "meaning",
    "terms",
    "understand",
    "basics",
    "learn",
    "show",
    "give",
    "some",
    "hai",
    "kya",
    "kaise",
    "mujhe",
    "mere",
    "mein",
    "mera",
    "meri",
    "kiye",
    "ke",
    "ka",
    "ki",
    "ko",
    "se",
    "aur",
    "ek",
    "kar",
    "karo",
    "batao",
    "samjhao",
    "kuch",
    "mujhko",
    "iska",
    "iski",
    "bataiye",
    "zara",
    "मुझे",
    "मेरा",
    "मेरी",
    "मेरे",
    "में",
    "है",
    "का",
    "की",
    "के",
    "को",
    "से",
    "और",
    "एक",
    "बताओ",
    "समझाओ",
    "बारे",
    "करो",
  ]);
  function tokenize(text) {
    return (
      String(text || "")
        .toLowerCase()
        .match(/[\p{L}\p{M}\p{N}]+/gu) || []
    ).filter((word) => word.length > 2 && !topicStopWords.has(word));
  }
  function inferTopic(text) {
    if (/\d\s*[\+\-×÷=\/]\s*\d/.test(String(text || "")))
      return "Math & numbers";
    const tokens = new Set(tokenize(text));
    let best = null;
    let score = 0;
    topicRules.forEach((rule) => {
      const matches = rule.words
        .split(" ")
        .filter((word) => tokens.has(word)).length;
      if (matches > score) {
        score = matches;
        best = rule.name;
      }
    });
    if (best) return best;
    const meaningful = tokenize(text);
    return meaningful.length
      ? `${meaningful[0][0].toUpperCase()}${meaningful[0].slice(1)}`
      : "Everyday questions";
  }
  function conciseTitle(text) {
    const cleaned = String(text || "")
      .replace(/\s+/g, " ")
      .replace(/[?!.।]+$/g, "")
      .trim();
    return cleaned.length > 48
      ? `${cleaned.slice(0, 45).trim()}…`
      : cleaned || "New conversation";
  }
  function matchingProject(topic, question = "") {
    const normalized = topic.toLowerCase();
    const targetTokens = new Set([...tokenize(topic), ...tokenize(question)]);
    const ranked = projects
      .map((project) => {
        if (project.name.toLowerCase() === normalized) {
          return { project, overlap: targetTokens.size || 1, score: 1 };
        }
        const projectChatTokens = chats
          .filter((chat) => chat.projectId === project.id)
          .flatMap((chat) => [
            chat.title,
            ...chat.messages
              .filter((message) => message.role === "user")
              .slice(0, 3)
              .map((message) => message.text),
          ])
          .flatMap(tokenize);
        const projectTokens = new Set([
          ...tokenize(project.name),
          ...projectChatTokens,
        ]);
        const overlap = [...targetTokens].filter((token) =>
          projectTokens.has(token),
        ).length;
        const score =
          overlap /
          Math.max(1, Math.min(targetTokens.size, projectTokens.size));
        return { project, overlap, score };
      })
      .sort((left, right) => right.score - left.score);
    const best = ranked[0];
    return best && best.overlap > 0 && best.score >= 0.28 ? best.project : null;
  }
  function projectById(id) {
    return projects.find((project) => project.id === id) || null;
  }
  function updateActiveProjectLabel() {
    const project = projectById(selectedProjectId);
    activeProjectLabel.hidden = !project;
    activeProjectLabel.textContent = project ? `In ${project.name}` : "";
  }
  function renderSidebar() {
    projectList.replaceChildren();
    const orderedProjects = [...projects].sort((a, b) =>
      String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")),
    );
    if (!orderedProjects.length) {
      const empty = document.createElement("div");
      empty.className = "sidebar-empty";
      empty.textContent = "Your projects will appear here.";
      projectList.append(empty);
    } else
      orderedProjects.forEach((project) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = `sidebar-item${selectedProjectId === project.id ? " active" : ""}`;
        button.setAttribute("aria-label", `Open project ${project.name}`);
        const symbol = document.createElement("span");
        symbol.className = "item-symbol";
        symbol.setAttribute("aria-hidden", "true");
        symbol.textContent = "▱";
        const name = document.createElement("span");
        name.className = "item-name";
        name.textContent = project.name;
        button.append(symbol, name);
        button.addEventListener("click", () => openProject(project.id));
        projectList.append(button);
      });
    recentList.replaceChildren();
    const orderedChats = [...chats]
      .sort((a, b) =>
        String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")),
      )
      .slice(0, 40);
    if (!orderedChats.length) {
      const empty = document.createElement("div");
      empty.className = "sidebar-empty";
      empty.textContent = "No chats yet. Start with a question.";
      recentList.append(empty);
    } else
      orderedChats.forEach((chat) => {
        const button = document.createElement("button");
        button.type = "button";
        button.className = `sidebar-item${activeChatId === chat.id ? " active" : ""}`;
        button.setAttribute(
          "aria-label",
          `Open chat: ${chat.title || "Untitled chat"}`,
        );
        const symbol = document.createElement("span");
        symbol.className = "item-symbol";
        symbol.setAttribute("aria-hidden", "true");
        symbol.textContent = "↗";
        const name = document.createElement("span");
        name.className = "item-name";
        name.textContent = chat.title || "Untitled chat";
        button.append(symbol, name);
        button.addEventListener("click", () => openChat(chat.id));
        recentList.append(button);
      });
    updateActiveProjectLabel();
  }
  function saveCurrentChat() {
    const chat = chats.find((item) => item.id === activeChatId);
    if (!chat) return;
    chat.projectId = selectedProjectId;
    chat.messages = history.map((item) => ({
      role: item.role,
      text: item.text,
      ...(item.attachmentNames?.length
        ? { attachmentNames: item.attachmentNames }
        : {}),
    }));
    chat.updatedAt = now();
    const project = projectById(chat.projectId);
    if (project) project.updatedAt = chat.updatedAt;
    persistWorkspace();
    renderSidebar();
  }
  function createProject(name) {
    const clean = String(name || "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 48);
    if (!clean) return null;
    const existing = projects.find(
      (project) => project.name.toLowerCase() === clean.toLowerCase(),
    );
    if (existing) {
      existing.updatedAt = now();
      return existing;
    }
    const project = {
      id: makeId(),
      name: clean,
      createdAt: now(),
      updatedAt: now(),
    };
    projects.push(project);
    persistWorkspace();
    renderSidebar();
    return project;
  }
  function startNewChat(projectId = null, explicit = false) {
    if (sending || preparingRequest) {
      showError(
        "Wait for the current response to finish before changing chats.",
      );
      return;
    }
    stopSpeech();
    activeChatId = null;
    selectedProjectId = projectId;
    explicitlySelectedProject = explicit;
    history.splice(0);
    messages.replaceChildren();
    welcome.hidden = false;
    hideError();
    imageStatus.hidden = true;
    input.value = "";
    input.style.height = "auto";
    clearAttachments();
    renderSidebar();
    closeMobileNav();
    input.focus();
  }
  function openProject(projectId) {
    if (sending || preparingRequest) {
      showError(
        "Wait for the current response to finish before changing chats.",
      );
      return;
    }
    const project = projectById(projectId);
    if (!project) return;
    const newest = chats
      .filter((chat) => chat.projectId === projectId)
      .sort((a, b) =>
        String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")),
      )[0];
    if (newest) openChat(newest.id);
    else startNewChat(projectId, true);
    closeMobileNav();
  }
  function openChat(chatId) {
    if (sending || preparingRequest) {
      showError(
        "Wait for the current response to finish before changing chats.",
      );
      return;
    }
    const chat = chats.find((item) => item.id === chatId);
    if (!chat) return;
    stopSpeech();
    activeChatId = chat.id;
    selectedProjectId = chat.projectId || null;
    explicitlySelectedProject = Boolean(chat.projectId);
    history.splice(
      0,
      history.length,
      ...chat.messages.map((item) => ({
        role: item.role,
        text: item.text,
        ...(item.attachmentNames
          ? { attachmentNames: item.attachmentNames }
          : {}),
      })),
    );
    messages.replaceChildren();
    chat.messages.forEach((item) =>
      addMessage(item.role, item.text, [], item.attachmentNames || []),
    );
    welcome.hidden = chat.messages.length > 0;
    input.value = "";
    input.style.height = "auto";
    imageStatus.textContent = "";
    imageStatus.hidden = true;
    hideError();
    clearAttachments();
    renderSidebar();
    closeMobileNav();
    input.focus();
  }
  function ensureCurrentChat(firstQuestion) {
    if (activeChatId && chats.some((chat) => chat.id === activeChatId))
      return chats.find((chat) => chat.id === activeChatId);
    const timestamp = now();
    if (!explicitlySelectedProject && !selectedProjectId) {
      const topic = inferTopic(firstQuestion);
      const match = matchingProject(topic, firstQuestion);
      const project = match || createProject(topic);
      selectedProjectId = project.id;
      project.updatedAt = timestamp;
    }
    const chat = {
      id: makeId(),
      projectId: selectedProjectId,
      title: conciseTitle(firstQuestion),
      createdAt: timestamp,
      updatedAt: timestamp,
      messages: [],
    };
    chats.push(chat);
    activeChatId = chat.id;
    renderSidebar();
    return chat;
  }
  function closeMobileNav() {
    sidebar.classList.remove("mobile-open");
    mobileMenuButton.setAttribute("aria-expanded", "false");
    document.getElementById("sidebar-backdrop")?.classList.remove("visible");
  }
  const allowedTypes = new Set([
    "image/png",
    "image/jpeg",
    "image/webp",
    "image/gif",
  ]);
  const maxImageBytes = 4 * 1024 * 1024;
  const maxTotalImageBytes = 10 * 1024 * 1024;
  let pendingImageReads = 0;
  let pendingImageBytes = 0;
  let preparingRequest = false;
  const imageReadWaiters = [];
  let sending = false;
  let typingNode = null;
  let activeSpeechSession = null;
  const speechAvailable =
    "speechSynthesis" in window && "SpeechSynthesisUtterance" in window;

  function scrollToLatest() {
    window.requestAnimationFrame(() => {
      window.scrollTo({
        top: document.documentElement.scrollHeight,
        behavior: "smooth",
      });
    });
  }

  function imagePayload(image) {
    return { mimeType: image.mimeType, data: image.data };
  }

  function clearAttachments() {
    attachments.splice(0, attachments.length);
    renderAttachments();
  }

  function finishImageRead(size) {
    pendingImageReads -= 1;
    pendingImageBytes -= size;
    if (pendingImageReads === 0) {
      imageReadWaiters.splice(0).forEach((resolve) => resolve());
    }
  }

  function waitForImageReads() {
    if (pendingImageReads === 0) return Promise.resolve();
    return new Promise((resolve) => imageReadWaiters.push(resolve));
  }

  function renderAttachments() {
    attachmentTray.replaceChildren();
    attachmentTray.hidden = attachments.length === 0;
    attachments.forEach((image, index) => {
      const item = document.createElement("div");
      item.className = "attachment-preview";
      const preview = document.createElement("img");
      preview.src = image.url;
      preview.alt = `Image attachment ${index + 1}: ${image.name}`;
      const remove = document.createElement("button");
      remove.type = "button";
      remove.className = "remove-attachment";
      remove.setAttribute("aria-label", `Remove ${image.name}`);
      remove.textContent = "×";
      remove.addEventListener("click", () => {
        URL.revokeObjectURL(image.url);
        attachments.splice(index, 1);
        renderAttachments();
      });
      item.append(preview, remove);
      attachmentTray.append(item);
    });
  }

  function addImages(fileList) {
    const files = Array.from(fileList || []);
    let reservedCount = attachments.length + pendingImageReads;
    let reservedBytes =
      attachments.reduce((total, image) => total + image.size, 0) +
      pendingImageBytes;
    for (const file of files) {
      if (reservedCount >= 3) {
        showError("You can attach up to 3 images per message.");
        break;
      }
      if (!allowedTypes.has(file.type)) {
        showError("Use a PNG, JPEG, WebP, or GIF image.");
        continue;
      }
      if (file.size > maxImageBytes) {
        showError(`${file.name || "This image"} is larger than 4 MiB.`);
        continue;
      }
      if (reservedBytes + file.size > maxTotalImageBytes) {
        showError("The combined image size must be 10 MiB or smaller.");
        continue;
      }
      reservedCount += 1;
      reservedBytes += file.size;
      pendingImageReads += 1;
      pendingImageBytes += file.size;
      const reader = new FileReader();
      reader.addEventListener("load", () => {
        finishImageRead(file.size);
        const result = String(reader.result || "");
        const comma = result.indexOf(",");
        if (comma < 0) {
          showError("That image could not be read. Please choose it again.");
          return;
        }
        attachments.push({
          name: file.name || `Image ${attachments.length + 1}`,
          mimeType: file.type,
          data: result.slice(comma + 1),
          url: URL.createObjectURL(file),
          size: file.size,
        });
        renderAttachments();
      });
      reader.addEventListener("error", () => {
        finishImageRead(file.size);
        showError("That image could not be read. Please choose it again.");
      });
      try {
        reader.readAsDataURL(file);
      } catch {
        finishImageRead(file.size);
        showError("That image could not be read. Please choose it again.");
      }
    }
    imageInput.value = "";
  }

  function setVoiceButton(button, isSpeaking, label) {
    button.setAttribute("aria-pressed", String(isSpeaking));
    button.setAttribute(
      "aria-label",
      isSpeaking ? "Stop reading this answer aloud" : "Read this answer aloud",
    );
    button.innerHTML = isSpeaking
      ? '<svg viewBox="0 0 20 20" aria-hidden="true"><rect x="5" y="5" width="10" height="10" rx="2" fill="currentColor"/></svg><span>Stop voice</span>'
      : `<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3 8v4h3l4 3V5L6 8H3Z" fill="currentColor"/><path d="M13 7.5a4 4 0 0 1 0 5M15 5a7 7 0 0 1 0 10" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg><span>${label || "Listen"}</span>`;
  }

  function endSpeechSession(session) {
    if (activeSpeechSession !== session) return;
    activeSpeechSession = null;
    session.controller?.abort();
    if (session.audio) {
      session.audio.pause();
      if (session.audioUrl) URL.revokeObjectURL(session.audioUrl);
      session.audio.removeAttribute("src");
      session.audio.load();
    }
    session.row.classList.remove("is-speaking");
    setVoiceButton(session.button, false);
    stopVoiceButton.hidden = true;
    topbarRight.classList.remove("voice-active");
  }

  function stopSpeech() {
    const session = activeSpeechSession;
    if (!session) return;
    activeSpeechSession = null;
    session.controller?.abort();
    if (session.audio) {
      session.audio.pause();
      if (session.audioUrl) URL.revokeObjectURL(session.audioUrl);
      session.audio.removeAttribute("src");
      session.audio.load();
    }
    if (speechAvailable) window.speechSynthesis.cancel();
    session.row.classList.remove("is-speaking");
    setVoiceButton(session.button, false);
    stopVoiceButton.hidden = true;
    topbarRight.classList.remove("voice-active");
  }

  function speechChunks(text) {
    const normalized = text.replace(/\s+/g, " ").trim();
    if (!normalized) return [];
    const sentences = normalized.match(/[^.!?।]+[.!?।]?/g) || [normalized];
    const chunks = [];
    let current = "";
    for (const sentence of sentences) {
      let remainder = sentence.trim();
      while (remainder.length > 220) {
        let splitAt = remainder.lastIndexOf(" ", 220);
        if (splitAt < 120) splitAt = 220;
        if (current) chunks.push(current);
        current = "";
        chunks.push(remainder.slice(0, splitAt).trim());
        remainder = remainder.slice(splitAt).trim();
      }
      if (!remainder) continue;
      if (current && current.length + remainder.length + 1 > 220) {
        chunks.push(current);
        current = remainder;
      } else {
        current = current ? `${current} ${remainder}` : remainder;
      }
    }
    if (current) chunks.push(current);
    return chunks;
  }

  function spokenText(text) {
    return text
      .replace(/\p{Extended_Pictographic}/gu, " ")
      .replace(/[\uFE0E\uFE0F\u200D\u{1F3FB}-\u{1F3FF}]/gu, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function fallbackSpeech(session, text) {
    if (!speechAvailable || activeSpeechSession !== session) {
      endSpeechSession(session);
      return;
    }
    session.mode = "browser";
    session.chunks = speechChunks(spokenText(text));
    session.index = 0;
    const next = () => {
      if (activeSpeechSession !== session) return;
      if (session.index >= session.chunks.length) {
        endSpeechSession(session);
        return;
      }
      const utterance = new window.SpeechSynthesisUtterance(
        session.chunks[session.index++],
      );
      utterance.lang = /[\u0900-\u097f]/i.test(text)
        ? "hi-IN"
        : navigator.language || "en-US";
      utterance.onend = next;
      utterance.onerror = () => endSpeechSession(session);
      try {
        window.speechSynthesis.speak(utterance);
      } catch {
        endSpeechSession(session);
      }
    };
    if (!session.chunks.length) endSpeechSession(session);
    else next();
  }

  async function speakAnswer(text, row, button) {
    if (activeSpeechSession?.button === button) {
      stopSpeech();
      return;
    }
    stopSpeech();
    const session = {
      row,
      button,
      controller: new AbortController(),
      audio: null,
    };
    activeSpeechSession = session;
    row.classList.add("is-speaking");
    setVoiceButton(button, true, "Preparing voice");
    stopVoiceButton.hidden = false;
    topbarRight.classList.add("voice-active");
    try {
      const response = await fetch("/api/voice", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: spokenText(text) }),
        signal: session.controller.signal,
      });
      const data = await response.json();
      if (
        !response.ok ||
        !data?.audio?.data ||
        activeSpeechSession !== session
      ) {
        throw new Error(data?.error || "Voice service unavailable");
      }
      const binary = atob(data.audio.data);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i += 1)
        bytes[i] = binary.charCodeAt(i);
      const audioUrl = URL.createObjectURL(
        new Blob([bytes], { type: data.audio.mimeType || "audio/wav" }),
      );
      const audio = new Audio(audioUrl);
      session.audio = audio;
      session.audioUrl = audioUrl;
      audio.addEventListener(
        "ended",
        () => {
          endSpeechSession(session);
        },
        { once: true },
      );
      audio.addEventListener(
        "error",
        () => {
          fallbackSpeech(session, text);
        },
        { once: true },
      );
      setVoiceButton(button, true, "Stop voice");
      await audio.play();
    } catch (error) {
      if (error.name === "AbortError" || activeSpeechSession !== session)
        return;
      fallbackSpeech(session, text);
    }
  }

  function addMessage(role, text, images = [], attachmentNames = []) {
    const row = document.createElement("article");
    row.className = `message ${role === "user" ? "user" : "model"}`;
    if (role === "model") {
      const avatar = document.createElement("span");
      avatar.className = "message-avatar";
      avatar.setAttribute("aria-hidden", "true");
      avatar.innerHTML =
        '<svg viewBox="0 0 40 40" fill="none"><path d="M8 12.5c0-1.1.9-2 2-2h20c1.1 0 2 .9 2 2v15c0 1.1-.9 2-2 2H10c-1.1 0-2-.9-2-2v-15Z" stroke="currentColor" stroke-width="2"/><path d="M14 17h12M14 21h9M14 25h6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
      row.append(avatar);
    }
    const body = document.createElement("div");
    body.className = "message-body";
    const meta = document.createElement("div");
    meta.className = "message-meta";
    meta.textContent = role === "user" ? "YOU" : "STUDYBUDDY";
    const content = document.createElement("div");
    content.className = "message-text";
    content.textContent = text;
    body.append(meta, content);
    if (images.length) {
      const previews = document.createElement("div");
      previews.className = "message-images";
      images.forEach((image, index) => {
        const img = document.createElement("img");
        img.src = image.url || `data:${image.mimeType};base64,${image.data}`;
        img.alt = `Attached image ${index + 1}`;
        previews.append(img);
      });
      body.append(previews);
    } else if (attachmentNames.length) {
      const placeholder = document.createElement("div");
      placeholder.className = "attachment-placeholder";
      placeholder.textContent = `${attachmentNames.length} attachment${attachmentNames.length === 1 ? "" : "s"} not saved on this device`;
      placeholder.setAttribute(
        "aria-label",
        `${attachmentNames.length} image attachment${attachmentNames.length === 1 ? "" : "s"}; image data is not saved`,
      );
      body.append(placeholder);
    }
    if (role === "model" && text.trim()) {
      const actions = document.createElement("div");
      actions.className = "message-actions";
      const voiceButton = document.createElement("button");
      voiceButton.className = "voice-button";
      voiceButton.type = "button";
      voiceButton.setAttribute("aria-pressed", "false");
      voiceButton.setAttribute("aria-label", "Read this answer aloud");
      setVoiceButton(voiceButton, false);
      voiceButton.addEventListener("click", () =>
        speakAnswer(text, row, voiceButton),
      );
      actions.append(voiceButton);
      body.append(actions);
    }
    row.append(body);
    messages.append(row);
    scrollToLatest();
    return row;
  }

  function setLoading(isLoading) {
    sending = isLoading;
    sendButton.disabled = isLoading;
    input.disabled = isLoading;
    attachButton.disabled = isLoading;
    sendButton.querySelector(".send-label").textContent = isLoading
      ? "Thinking"
      : "Send";
    sendButton.setAttribute(
      "aria-label",
      isLoading ? "StudyBuddy is thinking" : "Send message",
    );
    if (isLoading) {
      typingNode = addMessage("model", "");
      const text = typingNode.querySelector(".message-text");
      text.setAttribute("aria-label", "StudyBuddy is thinking");
      const dots = document.createElement("span");
      dots.className = "typing-dots";
      dots.setAttribute("aria-hidden", "true");
      for (let i = 0; i < 3; i += 1)
        dots.append(document.createElement("span"));
      text.append(dots);
    } else if (typingNode) {
      typingNode.remove();
      typingNode = null;
    }
  }

  function showError(message) {
    errorBox.textContent = message;
    errorBox.hidden = false;
  }

  function hideError() {
    errorBox.textContent = "";
    errorBox.hidden = true;
  }

  async function submitMessage(rawMessage) {
    if (sending || preparingRequest) return;
    preparingRequest = true;
    try {
      await waitForImageReads();
    } finally {
      preparingRequest = false;
    }
    const message = rawMessage.trim();
    if ((!message && !attachments.length) || sending) return;
    const prompt = message || "Please analyze the attached image.";
    hideError();
    welcome.hidden = true;
    const sentImages = attachments.map(imagePayload);
    const visualImages = attachments.map((image) => ({ ...image }));
    const requestChat = ensureCurrentChat(prompt);
    const attachmentNames = visualImages.map(
      (image) => image.name || "Image attachment",
    );
    const userRow = addMessage("user", message, visualImages);
    const previousHistory = history
      .slice(-16)
      .map(({ role, text }) => ({ role, text }));
    history.push({
      role: "user",
      text: prompt,
      ...(attachmentNames.length ? { attachmentNames } : {}),
    });
    saveCurrentChat();
    input.value = "";
    input.style.height = "auto";
    clearAttachments();
    imageStatus.textContent = "";
    imageStatus.hidden = true;
    setLoading(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: prompt,
          history: previousHistory,
          images: sentImages,
        }),
      });
      const data = await response.json();
      if (data?.quota) { quotaState = data.quota; renderQuota(); }
      if (response.status === 429 && data?.quota) { quotaState = data.quota; renderQuota(); throw new Error(data.error || "Question limit reached."); }
      if (!response.ok || !data || typeof data.reply !== "string") {
        throw new Error(
          data?.error || "We couldn’t get a reply just now. Please try again.",
        );
      }
      history.push({ role: "model", text: data.reply });
      refreshQuota();
      setLoading(false);
      addMessage("model", data.reply);
      saveCurrentChat();
    } catch (error) {
      history.pop();
      setLoading(false);
      userRow.remove();
      if (!history.length) {
        chats = chats.filter((chat) => chat.id !== requestChat.id);
        activeChatId = null;
        persistWorkspace();
        renderSidebar();
      } else {
        saveCurrentChat();
      }
      welcome.hidden = history.length > 0;
      showError(
        error instanceof TypeError
          ? "We couldn’t reach StudyBuddy. Check your connection and try again."
          : error.message || "Something went wrong. Please try again.",
      );
      input.value = message;
      attachments.push(
        ...visualImages.map((image, index) => ({
          ...image,
          name: image.name || `Image ${index + 1}`,
        })),
      );
      renderAttachments();
      input.focus();
    }
  }

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    submitMessage(input.value);
  });
  newChatButton.addEventListener("click", () =>
    startNewChat(
      explicitlySelectedProject ? selectedProjectId : null,
      explicitlySelectedProject,
    ),
  );
  newProjectButton.addEventListener("click", () => {
    if (sending || preparingRequest) {
      showError(
        "Wait for the current response to finish before changing chats.",
      );
      return;
    }
    const name = window.prompt("Name your project");
    if (name === null) return;
    const project = createProject(name);
    if (!project) return;
    startNewChat(project.id, true);
  });
  mobileMenuButton.addEventListener("click", () => {
    const open = !sidebar.classList.contains("mobile-open");
    sidebar.classList.toggle("mobile-open", open);
    mobileMenuButton.setAttribute("aria-expanded", String(open));
    let backdrop = document.getElementById("sidebar-backdrop");
    if (!backdrop) {
      backdrop = document.createElement("button");
      backdrop.type = "button";
      backdrop.id = "sidebar-backdrop";
      backdrop.className = "sidebar-backdrop";
      backdrop.setAttribute("aria-label", "Close navigation");
      backdrop.addEventListener("click", closeMobileNav);
      document.body.append(backdrop);
    }
    backdrop.classList.toggle("visible", open);
  });
  stopVoiceButton.addEventListener("click", stopSpeech);
  window.addEventListener("pagehide", stopSpeech);
  attachButton.addEventListener("click", () => imageInput.click());
  imageInput.addEventListener("change", () => addImages(imageInput.files));
  input.addEventListener("paste", (event) => {
    const pasted = Array.from(event.clipboardData?.items || [])
      .filter((item) => item.kind === "file" && allowedTypes.has(item.type))
      .map((item) => item.getAsFile())
      .filter(Boolean);
    if (pasted.length) {
      event.preventDefault();
      addImages(pasted);
      imageStatus.hidden = false;
      imageStatus.textContent = "Screenshot attached. Add a question.";
    }
  });
  input.addEventListener("input", () => {
    input.style.height = "auto";
    input.style.height = `${Math.min(input.scrollHeight, 160)}px`;
    if (!errorBox.hidden) hideError();
  });
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      form.requestSubmit();
    }
  });
  document.querySelectorAll("[data-prompt]").forEach((button) => {
    button.addEventListener("click", () => {
      input.value = button.dataset.prompt || "";
      input.dispatchEvent(new Event("input", { bubbles: true }));
      form.requestSubmit();
    });
  });
  renderSidebar();
  if (chats.length) {
    const mostRecent = [...chats].sort((a, b) =>
      String(b.updatedAt || "").localeCompare(String(a.updatedAt || "")),
    )[0];
    openChat(mostRecent.id);
  }

  // Always open a fresh conversation on page load; older chats stay available in Recent chats.
  window.addEventListener("load", async () => {
    try {
      const { data } = await supabaseClient.auth.getSession();
      if (data?.session?.user) startNewChat();
    } catch (error) { console.warn("Could not initialize a fresh chat", error); }
  });

})();

const profileButton = document.getElementById("profileButton");
const profileDropdown = document.getElementById("profileDropdown");
const logoutButton = document.getElementById("logoutButton");

profileButton?.addEventListener("click", () => {
  if (document.getElementById("profileMenuContainer")?.hidden) return;
  profileDropdown.hidden = !profileDropdown.hidden;
  profileButton.setAttribute("aria-expanded", String(!profileDropdown.hidden));
});

document.addEventListener("click", (event) => {
  const container = document.getElementById("profileMenuContainer");
  if (container && !container.contains(event.target)) {
    profileDropdown.hidden = true;
    profileButton?.setAttribute("aria-expanded", "false");
  }
});

logoutButton?.addEventListener("click", async () => {
  const logoutMessage = document.getElementById("logoutMessage");
  logoutButton.disabled = true;
  logoutButton.innerHTML = '<span aria-hidden="true">…</span> Logging out';
  if (logoutMessage) { logoutMessage.hidden = true; logoutMessage.textContent = ""; }
  try {
    if (localStorage.getItem("studybuddy.guest") === "1") {
      localStorage.removeItem("studybuddy.guest");
      window.location.reload();
      return;
    }
    if (typeof window.studyBuddySignOut !== "function") throw new Error("Auth is not ready. Please refresh and try again.");
    await window.studyBuddySignOut();
    // onAuthStateChange switches back to the login screen; this fallback ensures the UI resets.
    profileDropdown.hidden = true;
  } catch (error) {
    if (logoutMessage) {
      logoutMessage.textContent = error?.message || "Logout failed. Please try again.";
      logoutMessage.hidden = false;
    } else {
      alert(error?.message || "Logout failed. Please try again.");
    }
  } finally {
    logoutButton.disabled = false;
    logoutButton.innerHTML = '<span aria-hidden="true">↪</span> Logout';
  }
});
