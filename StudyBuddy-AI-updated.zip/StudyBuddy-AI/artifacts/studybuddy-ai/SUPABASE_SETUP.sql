-- StudyBuddy AI: rolling 25-question / 24-hour quota
-- Run in Supabase Dashboard -> SQL Editor. No service-role key belongs in browser code.
create table if not exists public.studybuddy_question_quotas (
  visitor_id text primary key,
  used integer not null default 0 check (used >= 0 and used <= 25),
  reset_at timestamptz,
  updated_at timestamptz not null default now()
);
alter table public.studybuddy_question_quotas enable row level security;
revoke all on public.studybuddy_question_quotas from anon, authenticated;

create or replace function public.get_question_quota(p_visitor_id text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare q public.studybuddy_question_quotas%rowtype;
begin
  if p_visitor_id is null or length(p_visitor_id) > 80 then raise exception 'invalid visitor'; end if;
  select * into q from public.studybuddy_question_quotas where visitor_id = p_visitor_id;
  if not found or (q.reset_at is not null and q.reset_at <= now()) then
    return jsonb_build_object('used', 0, 'reset_at', null, 'remaining', 25);
  end if;
  return jsonb_build_object('used', q.used, 'reset_at', q.reset_at, 'remaining', greatest(0,25-q.used));
end; $$;

create or replace function public.consume_question_quota(p_visitor_id text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare q public.studybuddy_question_quotas%rowtype; t timestamptz := now();
begin
  if p_visitor_id is null or length(p_visitor_id) > 80 then raise exception 'invalid visitor'; end if;
  insert into public.studybuddy_question_quotas(visitor_id,used,reset_at,updated_at)
  values(p_visitor_id,0,null,t) on conflict(visitor_id) do nothing;
  select * into q from public.studybuddy_question_quotas where visitor_id=p_visitor_id for update;
  if q.reset_at is not null and q.reset_at <= t then
    update public.studybuddy_question_quotas set used=0,reset_at=null,updated_at=t where visitor_id=p_visitor_id returning * into q;
  end if;
  if q.used >= 25 then
    return jsonb_build_object('allowed',false,'used',q.used,'reset_at',q.reset_at,'remaining',0);
  end if;
  if q.used = 0 then
    update public.studybuddy_question_quotas set used=1,reset_at=t+interval '24 hours',updated_at=t where visitor_id=p_visitor_id returning * into q;
  else
    update public.studybuddy_question_quotas set used=used+1,updated_at=t where visitor_id=p_visitor_id returning * into q;
  end if;
  return jsonb_build_object('allowed',true,'used',q.used,'reset_at',q.reset_at,'remaining',greatest(0,25-q.used));
end; $$;

create or replace function public.release_question_quota(p_visitor_id text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare q public.studybuddy_question_quotas%rowtype;
begin
  select * into q from public.studybuddy_question_quotas where visitor_id=p_visitor_id for update;
  if not found then return jsonb_build_object('used',0,'reset_at',null); end if;
  if q.used <= 1 then
    update public.studybuddy_question_quotas set used=0,reset_at=null,updated_at=now() where visitor_id=p_visitor_id returning * into q;
  else
    update public.studybuddy_question_quotas set used=used-1,updated_at=now() where visitor_id=p_visitor_id returning * into q;
  end if;
  return jsonb_build_object('used',q.used,'reset_at',q.reset_at);
end; $$;

revoke all on function public.get_question_quota(text) from public, anon, authenticated;
revoke all on function public.consume_question_quota(text) from public, anon, authenticated;
revoke all on function public.release_question_quota(text) from public, anon, authenticated;
grant execute on function public.get_question_quota(text) to service_role;
grant execute on function public.consume_question_quota(text) to service_role;
grant execute on function public.release_question_quota(text) to service_role;
