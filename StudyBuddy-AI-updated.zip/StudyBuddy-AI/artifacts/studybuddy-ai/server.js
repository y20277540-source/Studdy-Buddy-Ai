import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import express from "express";
import { GoogleGenAI } from "@google/genai";
import { rateLimit } from "express-rate-limit";
import { createClient } from "@supabase/supabase-js";

const supabaseAdmin = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY,
);

const app = express();
app.use(express.json());


const port = Number(process.env.PORT || 3000);
const publicDirectory = path.join(
  path.dirname(fileURLToPath(import.meta.url)),
  "public",
);

const MAX_MESSAGE_LENGTH = 4_000;
const MAX_HISTORY_MESSAGES = 16;
const MAX_HISTORY_CHARACTERS = 24_000;
const MAX_IMAGES_PER_REQUEST = 3;
const MAX_IMAGE_SIZE_BYTES = 4 * 1024 * 1024;
const MAX_TOTAL_IMAGE_SIZE_BYTES = 10 * 1024 * 1024;
const GEMINI_MODEL = "gemini-3.5-flash-lite";
const GEMINI_VISION_MODEL = GEMINI_MODEL;
const GEMINI_IMAGE_MODEL = "gemini-3.1-flash-image";
const GEMINI_SPEECH_MODEL = "gemini-3.8-flash-tts";
const ALLOWED_IMAGE_TYPES = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/gif",
]);
const STUDY_BUDDY_INSTRUCTIONS = [
  "You are StudyBuddy, a friendly, capable assistant for students and anyone who needs help.",
  "Support schoolwork, general questions, everyday planning, brainstorming, writing, and practical tasks; do not limit yourself to studying.",
  "Use clear language and adapt your depth to what the person asks for.",
  "Reply in the same language as the user's latest message. If they use more than one language, reply in the predominant language.",
  "For learning questions, explain one step at a time rather than only giving final answers.",
  "For homework, guide the student through the reasoning and encourage them to try the next step.",
  "Be accurate, acknowledge uncertainty, and keep answers focused on the question.",
  "Include one to three relevant emojis naturally in each reply, without overusing them; skip emojis when a serious or sensitive topic makes them inappropriate.",
].join(" ");

function safeProviderText(value) {
  return String(value)
    .replace(/AIza[0-9A-Za-z_-]{20,}/g, "[REDACTED_API_KEY]")
    .replace(/(GEMINI_API_KEY\s*[:=]\s*)\S+/gi, "$1[REDACTED]")
    .slice(0, 1_200);
}

if (!Number.isInteger(port) || port < 1 || port > 65_535) {
  throw new Error(`Invalid PORT value: "${process.env.PORT}"`);
}

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use((request, response, next) => {
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  response.setHeader("X-Frame-Options", "DENY");
  next();
});
app.use(express.json({ limit: "16mb" }));

const chatRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: "You’ve sent a lot of questions. Take a short break and try again.",
  },
});

const imageRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 6,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: "Image creation is taking a short break. Please try again later.",
  },
});

const voiceRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 15,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error:
      "Voice playback has reached its short-term limit. Please try again later.",
  },
});

function isValidImageSignature(bytes, mimeType) {
  if (mimeType === "image/png") {
    return bytes
      .subarray(0, 8)
      .equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  }
  if (mimeType === "image/jpeg") {
    return bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  }
  if (mimeType === "image/webp") {
    return (
      bytes.toString("ascii", 0, 4) === "RIFF" &&
      bytes.toString("ascii", 8, 12) === "WEBP"
    );
  }
  if (mimeType === "image/gif") {
    return (
      bytes.toString("ascii", 0, 3) === "GIF" &&
      (bytes.toString("ascii", 3, 6) === "87a" ||
        bytes.toString("ascii", 3, 6) === "89a")
    );
  }
  return false;
}

function parseImageAttachments(value) {
  if (value === undefined) return { images: [] };
  if (!Array.isArray(value)) {
    return { error: "Images must be sent as a list.", statusCode: 400 };
  }
  if (value.length > MAX_IMAGES_PER_REQUEST) {
    return {
      error: `Attach up to ${MAX_IMAGES_PER_REQUEST} images at a time.`,
      statusCode: 400,
    };
  }

  let totalBytes = 0;
  const images = [];
  for (const image of value) {
    if (
      !image ||
      typeof image !== "object" ||
      !ALLOWED_IMAGE_TYPES.has(image.mimeType) ||
      typeof image.data !== "string" ||
      !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(
        image.data,
      )
    ) {
      return {
        error: "Use valid PNG, JPG, WebP, or GIF images.",
        statusCode: 400,
      };
    }

    const bytes = Buffer.from(image.data, "base64");
    if (!bytes.length || bytes.length > MAX_IMAGE_SIZE_BYTES) {
      return {
        error: "Each image must be 4 MB or smaller.",
        statusCode: 413,
      };
    }
    totalBytes += bytes.length;
    if (totalBytes > MAX_TOTAL_IMAGE_SIZE_BYTES) {
      return {
        error: "The combined image size must be 10 MB or smaller.",
        statusCode: 413,
      };
    }
    if (!isValidImageSignature(bytes, image.mimeType)) {
      return {
        error: "An uploaded image doesn't match its file type.",
        statusCode: 400,
      };
    }
    images.push({ mimeType: image.mimeType, data: bytes.toString("base64") });
  }

  return { images };
}

function getGeminiErrorStatus(error) {
  if (!error || typeof error !== "object") return undefined;
  if (typeof error.status === "number") return error.status;
  if (typeof error.statusCode === "number") return error.statusCode;
  return undefined;
}

function handleGeminiFailure(response, error, operation) {
  const upstreamStatus = getGeminiErrorStatus(error);
  let providerError =
    error &&
    typeof error === "object" &&
    error.error &&
    typeof error.error === "object"
      ? error.error
      : undefined;
  if (!providerError && typeof error?.message === "string") {
    try {
      const parsedMessage = JSON.parse(error.message);
      providerError =
        parsedMessage?.error && typeof parsedMessage.error === "object"
          ? parsedMessage.error
          : undefined;
    } catch {
      // Keep the original SDK message as the fallback below.
    }
  }
  const details = Array.isArray(providerError?.details)
    ? providerError.details
        .map((detail) => {
          if (!detail || typeof detail !== "object") return undefined;
          if (typeof detail.reason === "string") return detail.reason;
          if (typeof detail["@type"] === "string") {
            return detail["@type"].split("/").at(-1);
          }
          return undefined;
        })
        .filter(Boolean)
        .slice(0, 4)
    : [];
  const providerMessage =
    typeof providerError?.message === "string"
      ? providerError.message
      : typeof error?.message === "string"
        ? error.message
        : "No provider message returned";
  const quotaMetrics =
    providerMessage.match(/Quota exceeded for metric:[^\r\n]*/g)?.slice(0, 4) ??
    [];

  // Log only Google response metadata; never request content, headers, or raw SDK objects.
  console.error(
    `[StudyBuddy] ${operation} Gemini upstream error`,
    JSON.stringify({
      httpStatus: upstreamStatus ?? null,
      providerCode:
        typeof providerError?.code === "number" ? providerError.code : null,
      providerStatus:
        typeof providerError?.status === "string" ? providerError.status : null,
      reasons: details,
      quotaMetrics: quotaMetrics.map(safeProviderText),
      message: safeProviderText(providerMessage),
    }),
  );

  if (upstreamStatus === 429) {
    response.status(429).json({
      error:
        operation === "Image generation" &&
        /Quota exceeded for metric:/i.test(providerMessage) &&
        /limit:\s*0\b/i.test(providerMessage)
          ? "This Gemini API key has no image-generation free-tier quota. Enable Gemini API billing or use a key with image-generation quota, then try again."
          : "Gemini is busy or has reached a quota limit. Please check the Gemini API quota and try again later.",
    });
    return;
  }
  if (upstreamStatus === 503) {
    response.status(503).json({
      error: "Gemini is temporarily unavailable. Please try again in a moment.",
    });
    return;
  }
  if (upstreamStatus === 404) {
    response.status(502).json({
      error:
        "The configured Gemini model wasn't found. Please try again later.",
    });
    return;
  }
  if (upstreamStatus === 401 || upstreamStatus === 403) {
    response.status(503).json({
      error:
        "Gemini access was denied. Check that GEMINI_API_KEY is valid and the Gemini API is enabled.",
    });
    return;
  }
  response.status(502).json({
    error: "StudyBuddy couldn't reach Gemini. Please try again in a moment.",
  });
}

// Anonymous rolling 24-hour question quota. The HttpOnly cookie is generated by the server.
const QUOTA_COOKIE = "sb_visitor";
function getVisitorId(request, response) {
  const cookies = Object.fromEntries(String(request.headers.cookie || "").split(";").map((part) => part.trim()).filter(Boolean).map((part) => { const i = part.indexOf("="); return i < 0 ? [part, ""] : [part.slice(0, i), decodeURIComponent(part.slice(i + 1))]; }));
  let id = cookies[QUOTA_COOKIE];
  if (!id || !/^[a-f0-9-]{36}$/i.test(id)) {
    id = crypto.randomUUID();
    response.cookie; // intentionally no cookie middleware dependency
    response.setHeader("Set-Cookie", `${QUOTA_COOKIE}=${id}; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000${process.env.NODE_ENV === "production" ? "; Secure" : ""}`);
  }
  return id;
}
async function quotaRpc(name, visitorId) {
  if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) return { unavailable: true };
  const { data, error } = await supabaseAdmin.rpc(name, { p_visitor_id: visitorId });
  if (error) { console.error(`[StudyBuddy] quota RPC failed: ${name}`, error.message); return { unavailable: true }; }
  return Array.isArray(data) ? (data[0] || {}) : (data || {});
}
app.get("/api/quota", async (request, response) => {
  const visitorId = getVisitorId(request, response);
  const quota = await quotaRpc("get_question_quota", visitorId);
  if (quota.unavailable) return response.status(503).json({ error: "Question limit storage is not configured. Run the supplied Supabase SQL setup first." });
  response.setHeader("Cache-Control", "no-store");
  response.json({ used: Number(quota.used || 0), limit: 25, resetAt: quota.reset_at || null, remaining: Math.max(0, 25 - Number(quota.used || 0)) });
});

app.get("/healthz", (_request, response) => {
  response.json({ status: "ok" });
});

app.post("/api/chat", chatRateLimit, async (request, response) => {
  if (!process.env.GEMINI_API_KEY) {
    response.status(503).json({
      error:
        "StudyBuddy is not connected yet. Add GEMINI_API_KEY in Replit Secrets, then restart the app.",
    });
    return;
  }

  const body = request.body;
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    response.status(400).json({ error: "Send a message to get started." });
    return;
  }

  const message = typeof body.message === "string" ? body.message.trim() : "";
  const parsedImages = parseImageAttachments(body.images);
  if (parsedImages.error) {
    response
      .status(parsedImages.statusCode)
      .json({ error: parsedImages.error });
    return;
  }
  const images = parsedImages.images;
  const userMessage =
    message ||
    (images.length
      ? "Please describe this image and tell me what it shows."
      : "");
  if (!userMessage) {
    response.status(400).json({ error: "Please enter a question first." });
    return;
  }
  if (userMessage.length > MAX_MESSAGE_LENGTH) {
    response.status(400).json({
      error: `Keep your question under ${MAX_MESSAGE_LENGTH.toLocaleString()} characters.`,
    });
    return;
  }

  const rawHistory = body.history ?? [];
  if (!Array.isArray(rawHistory) || rawHistory.length > MAX_HISTORY_MESSAGES) {
    response.status(400).json({
      error: "This conversation is too long. Start a new chat and try again.",
    });
    return;
  }

  const history = [];
  let historyCharacters = 0;

  for (const item of rawHistory) {
    if (
      !item ||
      typeof item !== "object" ||
      (item.role !== "user" && item.role !== "model") ||
      typeof item.text !== "string" ||
      !item.text.trim() ||
      item.text.length > MAX_MESSAGE_LENGTH
    ) {
      response.status(400).json({
        error:
          "The conversation history is invalid. Start a new chat and try again.",
      });
      return;
    }

    historyCharacters += item.text.length;
    if (historyCharacters > MAX_HISTORY_CHARACTERS) {
      response.status(400).json({
        error: "This conversation is too long. Start a new chat and try again.",
      });
      return;
    }

    history.push({
      role: item.role,
      parts: [{ text: item.text }],
    });
  }

  const visitorId = getVisitorId(request, response);
  const quota = await quotaRpc("consume_question_quota", visitorId);
  if (quota.unavailable) return response.status(503).json({ error: "Question limit storage is not configured. Run the supplied Supabase SQL setup first." });
  if (!quota.allowed) return response.status(429).json({ error: "You’ve used all 25 questions. Your limit resets at the time shown in your account menu.", quota: { used: Number(quota.used || 25), limit: 25, resetAt: quota.reset_at || null, remaining: 0 } });

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const result = await ai.models.generateContent({
      model: images.length ? GEMINI_VISION_MODEL : GEMINI_MODEL,
      contents: [
        ...history,
        {
          role: "user",
          parts: [
            { text: userMessage },
            ...images.map(({ mimeType, data }) => ({
              inlineData: { mimeType, data },
            })),
          ],
        },
      ],
      config: {
        systemInstruction: STUDY_BUDDY_INSTRUCTIONS,
        temperature: 0.6,
        maxOutputTokens: 2_048,
      },
    });

    const reply = result.text?.trim();
    if (!reply) {
      await quotaRpc("release_question_quota", visitorId);
      response.status(502).json({
        error:
          "StudyBuddy couldn't create a reply. Please try asking another way.",
      });
      return;
    }

    response.json({ reply, quota: { used: Number(quota.used || 1), limit: 25, resetAt: quota.reset_at || null, remaining: Math.max(0, 25 - Number(quota.used || 1)) } });
  } catch (error) {
    await quotaRpc("release_question_quota", visitorId);
    handleGeminiFailure(response, error, "Chat");
  }
});

app.post("/api/images", imageRateLimit, async (request, response) => {
  if (!process.env.GEMINI_API_KEY) {
    response.status(503).json({
      error:
        "Gemini isn't configured yet. Add GEMINI_API_KEY to Replit Secrets.",
    });
    return;
  }

  const body = request.body;
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    response.status(400).json({ error: "Send a prompt or an image to start." });
    return;
  }

  const parsedImages = parseImageAttachments(body.images);
  if (parsedImages.error) {
    response
      .status(parsedImages.statusCode)
      .json({ error: parsedImages.error });
    return;
  }
  const images = parsedImages.images;
  const prompt = typeof body.prompt === "string" ? body.prompt.trim() : "";
  if (prompt.length > MAX_MESSAGE_LENGTH) {
    response.status(400).json({
      error: `Keep the image prompt under ${MAX_MESSAGE_LENGTH.toLocaleString()} characters.`,
    });
    return;
  }
  if (!prompt && images.length === 0) {
    response.status(400).json({
      error: "Describe the image you want, or attach a reference photo.",
    });
    return;
  }

  const imagePrompt =
    prompt || "Create a new, polished image inspired by this reference photo.";
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const result = await ai.models.generateContent({
      model: GEMINI_IMAGE_MODEL,
      contents: [
        {
          role: "user",
          parts: [
            { text: imagePrompt },
            ...images.map(({ mimeType, data }) => ({
              inlineData: { mimeType, data },
            })),
          ],
        },
      ],
      config: {
        responseModalities: ["TEXT", "IMAGE"],
      },
    });

    const responseParts = (result.candidates ?? []).flatMap(
      (candidate) => candidate.content?.parts ?? [],
    );
    const generatedImage = responseParts.find(
      (part) =>
        typeof part.inlineData?.data === "string" &&
        ALLOWED_IMAGE_TYPES.has(part.inlineData.mimeType),
    );
    if (!generatedImage) {
      response.status(502).json({
        error: "Gemini didn't return an image. Please try a different prompt.",
      });
      return;
    }

    response.set("Cache-Control", "no-store");
    response.json({
      text:
        responseParts
          .map((part) => part.text)
          .filter((text) => typeof text === "string")
          .join("\n")
          .trim() || "Your image is ready.",
      image: {
        mimeType: generatedImage.inlineData.mimeType,
        data: generatedImage.inlineData.data,
      },
    });
  } catch (error) {
    handleGeminiFailure(response, error, "Image generation");
  }
});

app.post("/api/voice", voiceRateLimit, async (request, response) => {
  if (!process.env.GEMINI_API_KEY) {
    response.status(503).json({
      error:
        "Gemini isn't configured yet. Add GEMINI_API_KEY to Replit Secrets.",
    });
    return;
  }

  const body = request.body;
  const text = body && typeof body.text === "string" ? body.text.trim() : "";
  if (!text) {
    response.status(400).json({ error: "There is no reply to read aloud." });
    return;
  }
  if (text.length > 6_000) {
    response.status(400).json({
      error: "This reply is too long for voice playback.",
    });
    return;
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const result = await ai.interactions.create({
      model: GEMINI_SPEECH_MODEL,
      input: [
        {
          type: "user_input",
          content: [
            {
              type: "text",
              text,
              annotations: [
                {
                  type: "speech_metadata",
                  style:
                    "Warm, natural, friendly conversational delivery. Speak clearly at an unhurried pace with natural pauses. Read the text exactly in its original language; do not translate or add words.",
                },
              ],
            },
          ],
        },
      ],
      response_format: { type: "audio" },
      generation_config: {
        speech_config: [{ voice: "Kore" }],
      },
      store: false,
    });

    const audioData = result.output_audio?.data;
    if (typeof audioData !== "string" || !audioData) {
      response.status(502).json({
        error: "Gemini didn't return voice audio. Please try again.",
      });
      return;
    }

    response.set("Cache-Control", "no-store");
    response.json({
      audio: {
        mimeType:
          result.output_audio?.mime_type ??
          result.output_audio?.mimeType ??
          "audio/wav",
        data: audioData,
      },
    });
  } catch (error) {
    handleGeminiFailure(response, error, "Voice");
  }
});

app.use(express.json());

app.use(express.static(publicDirectory, { index: "index.html" }));

app.use((error, _request, response, _next) => {
  if (error instanceof SyntaxError && "body" in error) {
    response
      .status(400)
      .json({ error: "The request body must be valid JSON." });
    return;
  }
  if (error?.type === "entity.too.large") {
    response.status(413).json({ error: "That request is too large." });
    return;
  }

  console.error("[StudyBuddy] Request could not be processed.");
  response
    .status(500)
    .json({ error: "Something went wrong. Please try again." });

});

app.listen(port, "0.0.0.0", () => {
  console.info(`[StudyBuddy] Listening on port ${port}.`);
});
